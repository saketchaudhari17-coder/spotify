# Midnight Frequencies

An after-hours music radio web app: a scroll-driven intro film, a Spotify-style library with playlists, liked songs and search, a full-screen Now Playing view, and a playable 3D studio.

Plain HTML, CSS and JavaScript. No build step needed.

## Run locally
Serve the folder with any static server, for example:

    npx serve .

Then open http://localhost:3000.

## Deploy on Vercel
1. Push this folder to a GitHub repository.
2. On vercel.com choose **Add New → Project** and import the repository.
3. Framework preset: **Other**. Leave the build command and output directory empty.
4. Click **Deploy**.

## Credits
Instrument samples in `assets/studio/`: Salamander Grand Piano, Iowa and Karoryfer guitar/bass samples (CC-BY 3.0, via nbrosowsky/tonejs-instruments) and Tone.js drum samples.
